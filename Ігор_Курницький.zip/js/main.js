$(document).ready(function() {
	$('#carousel-1, #carousel-2').carousel();
});